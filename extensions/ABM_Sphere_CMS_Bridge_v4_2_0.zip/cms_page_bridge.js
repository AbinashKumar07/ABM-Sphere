// ABM Sphere CMS Bridge v4.2.0 - runs in the CMS page's own JS world.
// Its only job is to hand article HTML to the page's real TinyMCE instance, so
// the editor's internal state and its hidden textarea stay in sync. It does not
// save, submit or call any network API.

(function () {
  "use strict";
  if (window.__abmBridgePageLoaded) return;
  window.__abmBridgePageLoaded = true;

  function pickEditor(tm, hintIds) {
    const editors = (tm.editors || []).filter(function (e) { return e && !e.removed && e.initialized; });
    if (!editors.length) return null;
    for (let i = 0; i < hintIds.length; i++) {
      const byId = tm.get(hintIds[i]);
      if (byId && !byId.removed) return byId;
    }
    const named = editors.filter(function (e) {
      const el = e.getElement && e.getElement();
      const key = ((el && (el.id + " " + el.name)) || e.id || "").toLowerCase();
      return /content|body|article|description_long|editor/.test(key);
    });
    if (named.length) return named[0];
    return editors.length === 1 ? editors[0] : tm.activeEditor && tm.activeEditor.initialized ? tm.activeEditor : editors[0];
  }

  document.addEventListener("abm-bridge:set-editor", function (ev) {
    let req = {};
    let out = { id: null, ok: false, method: "", error: "" };
    try {
      req = JSON.parse(ev.detail);
      out.id = req.id;
      const tm = window.tinymce || window.tinyMCE;
      if (!tm) {
        out.error = "tinymce-not-found";
      } else {
        const ed = pickEditor(tm, req.hintIds || []);
        if (!ed) {
          out.error = "editor-not-ready";
        } else {
          ed.undoManager && ed.undoManager.transact
            ? ed.undoManager.transact(function () { ed.setContent(req.html); })
            : ed.setContent(req.html);
          ed.save(); // sync the hidden textarea the form actually submits
          if (ed.setDirty) ed.setDirty(true);
          ed.fire && ed.fire("change");
          out.ok = true;
          out.method = "tinymce-api";
        }
      }
    } catch (e) {
      out.error = String(e && e.message ? e.message : e);
    }
    document.dispatchEvent(new CustomEvent("abm-bridge:set-editor-result", { detail: JSON.stringify(out) }));
  });
})();
