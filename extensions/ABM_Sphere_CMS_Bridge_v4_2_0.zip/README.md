# ABM Sphere CMS Bridge v4.2.0

Sends content from the ABM Immersive Content Manager into the MoMAGIC CMS form.

## Install
1. Unzip. Open the unzipped folder and confirm `manifest.json` is directly inside it.
2. Go to `chrome://extensions`, turn on Developer mode, click Load unpacked, select that folder.
3. Keep the folder where it is afterwards; Chrome reads it from there.
4. Using ABM from a local file (file:///)? On the extension's Details page turn on "Allow access to file URLs".

## Use
1. Open ABM and the CMS Create Article page in two tabs.
2. In ABM click "Send to MoMAGIC CMS". The CMS tab comes to the front and the fields fill in.
3. Filled fields get a brief green outline and a toast lists what was filled / not found.
4. Review, then press the CMS's own Save as usual.

## What gets filled
Article send: Title, Description, Remark and Content only. Category, Region and Meta fields are never touched.
URL send: Wallpaper Image Url and Feature Image Url only.
If Title or Description is longer than the CMS limit it is still filled in full and you get a warning.

## Safety
- Fills form fields only. Never clicks Save/Publish/Submit/Delete, never submits a form.
- Skips blank / "N/A" values, so it never empties an existing field.
- Ignores hidden, disabled and read-only fields and search boxes.
- Article HTML: scripts, iframes and event handlers are stripped; headings become bold paragraphs.
- No network requests, no analytics, no data stored.
- Permissions: `scripting` + access to content.thefactmagic.com only.

## Files
manifest.json, background.js (routing), content_abm.js (ABM page), content_cms.js (form filling),
cms_page_bridge.js (TinyMCE hand-off), popup.html/js, icons/.
