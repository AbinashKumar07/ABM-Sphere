// ABM Sphere CMS Bridge v4.2.0 - ABM page content script
// Translates window.postMessage from index.html into extension messages and
// posts the result back. Protocol is unchanged from earlier versions, so the
// existing ABM index.html works without edits.

(function () {
  "use strict";

  if (window.__abmBridgeAbmLoaded) return;
  window.__abmBridgeAbmLoaded = true;

  const VERSION = "4.2.0";
  const ACTIONS = ["SEND_ARTICLE_TO_CMS", "SEND_URLS_TO_CMS"];
  let sending = false;

  // Only act on the ABM app itself, not on every github.io / localhost page.
  function isAbmPage() {
    return /ABM/i.test(document.title || "");
  }

  function reply(action, status, message, detail) {
    window.postMessage(
      { type: "ABM_CMS_RESPONSE", action: action, status: status, message: message, detail: detail || null, timestamp: Date.now() },
      "*"
    );
  }

  function announce() {
    if (!isAbmPage()) return;
    document.documentElement.dataset.abmCmsBridge = VERSION;
    document.documentElement.dataset.abmBridgeActive = "true";
    window.postMessage({ type: "ABM_EXTENSION_PING", version: VERSION, bridgeReady: true, timestamp: Date.now() }, "*");
  }

  announce();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", announce, { once: true });
  }

  window.addEventListener("message", function (event) {
    if (event.source !== window || !event.data || typeof event.data !== "object") return;
    const req = event.data;

    if (req.type === "ABM_EXTENSION_CHECK") {
      announce();
      return;
    }
    if (req.type !== "ABM_CMS_PAYLOAD" || !isAbmPage()) return;

    const action =
      req.action || (req.mode === "url" || (req.data && req.data.wallpaperUrl) ? "SEND_URLS_TO_CMS" : "SEND_ARTICLE_TO_CMS");
    if (ACTIONS.indexOf(action) === -1) return;

    if (sending) {
      reply(action, "busy", "A transfer is already in progress. Please wait a moment.");
      return;
    }
    sending = true;

    const timer = setTimeout(function () {
      if (!sending) return;
      sending = false;
      reply(action, "error", "No answer from the extension after 20 seconds. Check that the CMS tab is open.");
    }, 20000);

    try {
      chrome.runtime.sendMessage({ action: action, data: req.data || {} }, function (response) {
        if (!sending) return; // already timed out
        clearTimeout(timer);
        sending = false;
        const err = chrome.runtime.lastError;
        if (err) {
          reply(action, "error", err.message);
        } else if (!response) {
          reply(action, "error", "The extension returned no response.");
        } else {
          reply(action, response.status, response.message, response.detail);
        }
      });
    } catch (e) {
      clearTimeout(timer);
      sending = false;
      reply(
        action,
        "error",
        "Extension was reloaded or updated. Refresh this ABM page once and try again. (" + (e && e.message ? e.message : e) + ")"
      );
    }
  });
})();
