// ABM Sphere CMS Bridge v4.2.0 - background service worker
// Routes a payload from the ABM page to the MoMAGIC CMS tab. It never touches
// the network; it only passes messages between tabs.

const CMS_PATTERN = "*://content.thefactmagic.com/*";
const CMS_HOME = "https://content.thefactmagic.com/admin";
const ACTIONS = {
  SEND_ARTICLE_TO_CMS: "POPULATE_CMS_FORM",
  SEND_URLS_TO_CMS: "POPULATE_CMS_URLS"
};
const MAX_FIELD_CHARS = 1000000; // sanity cap per text field

let busyUntil = 0; // timestamp-based so it survives worker restarts safely

function str(v) {
  return v === null || v === undefined ? "" : String(v).slice(0, MAX_FIELD_CHARS);
}

function normalize(action, raw) {
  const d = raw && typeof raw === "object" ? raw : {};
  if (action === "SEND_ARTICLE_TO_CMS") {
    return {
      title: str(d.title),
      desc: str(d.desc || d.description),
      remarks: str(d.remarks || d.remark),
      article: str(d.article || d.articleHtml)
    };
  }
  return {
    wallpaperUrl: str(d.wallpaperUrl).trim(),
    ciUrl: str(d.ciUrl).trim(),
    remarks: str(d.remarks || d.remark)
  };
}

function isEmptyPayload(action, d) {
  if (action === "SEND_ARTICLE_TO_CMS") return !d.title.trim() && !d.article.trim();
  return !d.wallpaperUrl && !d.ciUrl;
}

function sendToTab(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const err = chrome.runtime.lastError;
      resolve(err ? { __error: err.message } : response);
    });
  });
}

// If the CMS tab was open before the extension was installed/reloaded, its
// content scripts are missing. Inject them instead of asking for a refresh.
async function injectCmsScripts(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content_cms.js"] });
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["cms_page_bridge.js"],
    world: "MAIN"
  });
}

async function handle(action, rawData) {
  const data = normalize(action, rawData);
  if (isEmptyPayload(action, data)) {
    return {
      status: "error",
      message:
        action === "SEND_ARTICLE_TO_CMS"
          ? "Nothing to send: the title and article are both empty."
          : "Nothing to send: both image URLs are empty."
    };
  }

  const tabs = await chrome.tabs.query({ url: CMS_PATTERN });
  if (!tabs.length) {
    await chrome.tabs.create({ url: CMS_HOME });
    return {
      status: "opened",
      message: "MoMAGIC CMS was not open, so it was opened for you. Go to the Create Article page and click Send again."
    };
  }

  tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  const target = tabs[0];

  await chrome.tabs.update(target.id, { active: true });
  try {
    await chrome.windows.update(target.windowId, { focused: true });
  } catch (_) {}

  const message = { action: ACTIONS[action], data };
  let res = await sendToTab(target.id, message);

  if (res && res.__error) {
    try {
      await injectCmsScripts(target.id);
      res = await sendToTab(target.id, message);
    } catch (e) {
      return {
        status: "error",
        message: "Could not reach the CMS tab (" + (e && e.message ? e.message : e) + "). Refresh the CMS page once and try again."
      };
    }
  }

  if (!res || res.__error) {
    return {
      status: "error",
      message: "Could not reach the CMS tab" + (res && res.__error ? " (" + res.__error + ")" : "") + ". Refresh the CMS page once and try again."
    };
  }

  if (res.status === "busy") return { status: "busy", message: res.message };
  if (res.status === "error") return { status: "error", message: res.message || "The CMS page reported an error." };

  return {
    status: res.anyFilled ? "success" : "error",
    message: res.summary || (res.anyFilled ? "Content populated into the CMS." : "No matching CMS fields were found on this page."),
    detail: res
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (!request || !ACTIONS[request.action]) return false;

  // Only accept messages from our own content script running in a tab
  if (!sender || sender.id !== chrome.runtime.id || !sender.tab) return false;

  const now = Date.now();
  if (now < busyUntil) {
    sendResponse({ status: "busy", message: "A transfer is already in progress. Please wait a moment." });
    return false;
  }
  busyUntil = now + 15000;

  handle(request.action, request.data)
    .catch((e) => ({ status: "error", message: "Unexpected error: " + (e && e.message ? e.message : e) }))
    .then((res) => {
      busyUntil = 0;
      try {
        sendResponse(res);
      } catch (_) {}
    });

  return true; // async response
});
