document.getElementById("ver").textContent = "Version " + chrome.runtime.getManifest().version;

chrome.tabs.query({ url: "*://content.thefactmagic.com/*" }, function (tabs) {
  const open = !!(tabs && tabs.length);
  document.getElementById("dot").className = "dot" + (open ? " on" : "");
  document.getElementById("status").textContent = open
    ? "CMS tab open (" + tabs.length + ")"
    : "CMS tab not open";
});

document.getElementById("open").addEventListener("click", function () {
  chrome.tabs.query({ url: "*://content.thefactmagic.com/*" }, function (tabs) {
    if (tabs && tabs.length) {
      chrome.tabs.update(tabs[0].id, { active: true });
      chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: "https://content.thefactmagic.com/admin" });
    }
    window.close();
  });
});
