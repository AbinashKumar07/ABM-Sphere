// ABM Sphere CMS Bridge v4.2.0 - MoMAGIC CMS content script
//
// SAFETY CONTRACT (what this script will and will not do)
//  - It only writes into form controls that match the fields it was asked to fill.
//  - It skips blank values, so it never clears or overwrites a field with nothing.
//  - It never clicks Save / Publish / Submit / Delete and never submits a form.
//  - It makes no network requests of its own; the CMS saves exactly as it normally does.
//  - Hidden, disabled and read-only controls are ignored.

(function () {
  "use strict";

  if (window.__abmBridgeCmsLoaded) return;
  window.__abmBridgeCmsLoaded = true;

  let running = false;

  chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (!request || (request.action !== "POPULATE_CMS_FORM" && request.action !== "POPULATE_CMS_URLS")) return false;
    if (sender && sender.id && sender.id !== chrome.runtime.id) return false;

    if (running) {
      sendResponse({ status: "busy", message: "The CMS page is still filling the previous transfer." });
      return false;
    }
    running = true;

    const job = request.action === "POPULATE_CMS_FORM" ? fillArticle(request.data || {}) : fillUrls(request.data || {});
    job
      .then(function (result) {
        running = false; // release before replying so the next send is never rejected
        toast(result.summary, result.anyFilled ? "#1e88e5" : "#d32f2f");
        sendResponse(result);
      })
      .catch(function (e) {
        running = false;
        const message = "CMS fill error: " + (e && e.message ? e.message : e);
        toast(message, "#d32f2f");
        sendResponse({ status: "error", message: message });
      });

    return true; // async response
  });

  // ---------------------------------------------------------------------------
  // Transfers
  // ---------------------------------------------------------------------------

  async function fillUrls(d) {
    const report = newReport();

    if (!isBlank(d.wallpaperUrl)) {
      report.add(
        "Wallpaper URL",
        setField(findByLabel(["wallpaper image url", "wallpaper image", "wallpaper url"]) ||
          findByAttr(["wallpaper"], "input"), d.wallpaperUrl)
      );
    }
    if (!isBlank(d.ciUrl)) {
      report.add(
        "Feature URL",
        setField(findByLabel(["feature image url", "feature image", "feature url"]) ||
          findByAttr(["feature_image_url", "feature"], "input"), d.ciUrl)
      );
    }
    if (!isBlank(d.remarks)) {
      report.add("Remarks", setField(findRemarks(), d.remarks));
    }
    return report.finish();
  }

  async function fillArticle(d) {
    const report = newReport();

    // Only these four fields are ever touched: Title, Description, Remark, Content.
    // Each is independent: one failure never blocks the others.
    if (!isBlank(d.title)) {
      attempt(function () {
        const el = findByLabel(["article title", "title"], { exclude: ["meta", "sub"] }) ||
          findByAttr(["title"], "input", { exclude: ["meta", "search", "sub"] });
        report.add("Title", setField(el, d.title));
        warnIfOver(report, "Title", el, d.title);
      });
    }

    if (!isBlank(d.desc)) {
      attempt(function () {
        const el = findByLabel(["description"], { exclude: ["meta"] }) ||
          findByAttr(["description"], "textarea", { exclude: ["meta"] }) ||
          findByAttr(["description"], "input", { exclude: ["meta", "search"] });
        report.add("Description", setField(el, d.desc));
        warnIfOver(report, "Description", el, d.desc);
      });
    }

    if (!isBlank(d.remarks)) {
      report.add("Remark", attempt(function () { return setField(findRemarks(), d.remarks); }));
    }

    if (!isBlank(d.article)) {
      let ok = false;
      try {
        ok = await fillEditor(cleanHtml(d.article));
      } catch (_) {}
      report.add("Content", ok);
    }

    return report.finish();
  }

  // The CMS limits Title/Description length. We never cut the text; we just warn.
  function warnIfOver(report, name, el, value) {
    if (el && el.maxLength > 0 && String(value).length > el.maxLength) {
      report.warn(name + " is " + String(value).length + " chars (CMS limit " + el.maxLength + ")");
    }
  }

  // ---------------------------------------------------------------------------
  // Rich text editor (TinyMCE)
  // ---------------------------------------------------------------------------

  async function fillEditor(html) {
    const textarea = findContentTextarea();
    const hintIds = textarea && textarea.id ? [textarea.id] : [];

    // Preferred: use TinyMCE's own API (runs in the page's JS world) so the editor's
    // internal state and its hidden textarea are both updated correctly.
    for (let i = 0; i < 8; i++) {
      const res = await callPageBridge({ html: html, hintIds: hintIds });
      if (res && res.ok) return true;
      await sleep(500);
    }

    // Fallback: write straight into the editor iframe, then sync the textarea.
    let filled = false;
    const frames = document.querySelectorAll(".tox-edit-area iframe, iframe.tox-edit-area__iframe, iframe[id$='_ifr']");
    for (let i = 0; i < frames.length; i++) {
      try {
        const doc = frames[i].contentDocument;
        if (doc && doc.body) {
          doc.body.innerHTML = html;
          doc.body.dispatchEvent(new Event("input", { bubbles: true }));
          filled = true;
          break;
        }
      } catch (_) {}
    }
    if (textarea) filled = setField(textarea, html, { allowHidden: true }) || filled;
    return filled;
  }

  function findContentTextarea() {
    const list = ["textarea#content", "textarea[name='content']", "textarea.tox-target", "textarea[name*='content' i]", "textarea[name*='body' i]"];
    for (let i = 0; i < list.length; i++) {
      try {
        const el = document.querySelector(list[i]);
        if (el && !el.disabled && !el.readOnly) return el;
      } catch (_) {}
    }
    return null;
  }

  function callPageBridge(payload) {
    return new Promise(function (resolve) {
      const id = String(Date.now()) + Math.random().toString(16).slice(2);
      let done = false;

      function onResult(ev) {
        let out = null;
        try { out = JSON.parse(ev.detail); } catch (_) {}
        if (!out || out.id !== id) return;
        finish(out);
      }
      function finish(out) {
        if (done) return;
        done = true;
        document.removeEventListener("abm-bridge:set-editor-result", onResult);
        clearTimeout(timer);
        resolve(out);
      }

      document.addEventListener("abm-bridge:set-editor-result", onResult);
      const timer = setTimeout(function () { finish(null); }, 700);
      payload.id = id;
      document.dispatchEvent(new CustomEvent("abm-bridge:set-editor", { detail: JSON.stringify(payload) }));
    });
  }

  // Keeps the article's wanted formatting: headings become bold paragraphs and
  // inline colour/size/highlight styles are stripped. Also removes anything unsafe.
  function cleanHtml(html) {
    const t = document.createElement("template");
    t.innerHTML = String(html);
    const root = t.content;

    root.querySelectorAll("script,style,iframe,object,embed,link,meta,form").forEach(function (n) { n.remove(); });
    root.querySelectorAll("*").forEach(function (el) {
      Array.prototype.slice.call(el.attributes).forEach(function (a) {
        const name = a.name.toLowerCase();
        if (name.indexOf("on") === 0) el.removeAttribute(a.name);
        if ((name === "href" || name === "src") && /^\s*javascript:/i.test(a.value)) el.removeAttribute(a.name);
      });
    });

    root.querySelectorAll("h1,h2,h3,h4,h5,h6").forEach(function (h) {
      const p = document.createElement("p");
      const inner = h.innerHTML
        .replace(/<\/?(h[1-6]|span|div)[^>]*>/gi, "")
        .replace(/^<b>([\s\S]*?)<\/b>$/i, "$1")
        .replace(/^<strong>([\s\S]*?)<\/strong>$/i, "$1")
        .trim();
      p.innerHTML = "<b>" + inner + "</b>";
      h.parentNode.replaceChild(p, h);
    });

    root.querySelectorAll("[style]").forEach(function (el) {
      el.style.backgroundColor = "";
      el.style.color = "";
      el.style.fontSize = "";
      el.style.fontWeight = "";
      if (!(el.getAttribute("style") || "").trim()) el.removeAttribute("style");
    });

    const wrap = document.createElement("div");
    wrap.appendChild(root.cloneNode(true));
    return wrap.innerHTML;
  }

  // ---------------------------------------------------------------------------
  // Finding controls
  // ---------------------------------------------------------------------------

  const TEXT_TYPES = ["", "text", "url", "search"];

  function norm(s) {
    return String(s || "").toLowerCase().replace(/[*:]/g, " ").replace(/\s+/g, " ").trim();
  }

  function isVisible(el) {
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  }

  function usable(el, tag, allowHidden) {
    if (!el || el.disabled || el.readOnly) return false;
    const t = el.tagName.toLowerCase();
    if (tag && t !== tag) return false;
    if (t === "input" && TEXT_TYPES.indexOf((el.getAttribute("type") || "").toLowerCase()) === -1) return false;
    if (t !== "input" && t !== "textarea" && t !== "select") return false;
    return allowHidden || isVisible(el);
  }

  function controlsNear(label, tag, allowHidden) {
    const found = [];
    const forId = label.getAttribute("for");
    if (forId) {
      const byId = document.getElementById(forId);
      if (byId) found.push(byId);
    }
    label.querySelectorAll("input,textarea,select").forEach(function (c) { found.push(c); });

    let scope = label.parentElement;
    for (let depth = 0; scope && depth < 3 && !found.length; depth++, scope = scope.parentElement) {
      const inside = scope.querySelectorAll("input,textarea,select");
      // Only accept a container that clearly belongs to this one label
      if (inside.length && scope.querySelectorAll("label").length <= 1) {
        inside.forEach(function (c) { found.push(c); });
      }
    }
    return found.filter(function (c) { return usable(c, tag, allowHidden); });
  }

  // names: label texts to look for, best match first
  function findByLabel(names, opts) {
    opts = opts || {};
    const wanted = (Array.isArray(names) ? names : [names]).map(norm);
    const exclude = (opts.exclude || []).map(norm);
    const labels = Array.prototype.slice.call(document.querySelectorAll("label"));

    for (let n = 0; n < wanted.length; n++) {
      for (let i = 0; i < labels.length; i++) {
        const text = norm(labels[i].textContent);
        if (!text || (text !== wanted[n] && text.indexOf(wanted[n] + " ") !== 0)) continue;
        if (exclude.some(function (x) { return text.indexOf(x) !== -1; })) continue;
        const controls = controlsNear(labels[i], opts.tag, opts.allowHidden);
        if (controls.length) return controls[0];
      }
    }
    return null;
  }

  // keys: substrings to look for in placeholder / name / id
  function findByAttr(keys, tag, opts) {
    opts = opts || {};
    const exclude = (opts.exclude || []).map(norm);
    const list = document.querySelectorAll(tag || "input,textarea");
    for (let k = 0; k < keys.length; k++) {
      const key = norm(keys[k]);
      for (let i = 0; i < list.length; i++) {
        const el = list[i];
        const hay = norm((el.getAttribute("placeholder") || "") + " " + (el.getAttribute("name") || "") + " " + (el.id || ""));
        if (hay.indexOf(key) === -1) continue;
        if (exclude.some(function (x) { return hay.indexOf(x) !== -1; })) continue;
        if (usable(el, tag)) return el;
      }
    }
    return null;
  }

  function findRemarks() {
    return (
      findByLabel(["remarks", "remark"]) ||
      findByAttr(["remark"], "textarea") ||
      findByAttr(["remark"], "input")
    );
  }

  // ---------------------------------------------------------------------------
  // Writing values
  // ---------------------------------------------------------------------------

  function isBlank(v) {
    if (v === null || v === undefined) return true;
    const s = String(v).trim().toUpperCase();
    return s === "" || s === "N/A" || s === "NULL";
  }

  function setField(el, value, opts) {
    opts = opts || {};
    if (!el || !usable(el, null, opts.allowHidden)) return false;
    let text = String(value);

    if (opts.respectMaxLength && el.maxLength > 0 && text.length > el.maxLength) {
      const cut = text.slice(0, el.maxLength);
      const space = cut.lastIndexOf(" ");
      text = (space > el.maxLength * 0.6 ? cut.slice(0, space) : cut).trim();
    }

    if (el.value !== text) {
      const proto = el.tagName.toLowerCase() === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(el, text);
      else el.value = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    flash(el);
    return true;
  }

  function flash(el) {
    if (!isVisible(el)) return;
    const prev = el.style.outline;
    const prevOffset = el.style.outlineOffset;
    el.style.outline = "2px solid #00c853";
    el.style.outlineOffset = "1px";
    setTimeout(function () {
      el.style.outline = prev;
      el.style.outlineOffset = prevOffset;
    }, 2500);
  }

  // ---------------------------------------------------------------------------
  // Reporting
  // ---------------------------------------------------------------------------

  function attempt(fn) {
    try { return !!fn(); } catch (_) { return false; }
  }


  function sleep(ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  }

  function newReport() {
    const filled = [];
    const missed = [];
    const warnings = [];
    return {
      warn: function (msg) { warnings.push(msg); },
      add: function (name, ok, note) { (ok ? filled : missed).push(ok || !note ? name : name + " (" + note + ")"); },
      finish: function () {
        const anyFilled = filled.length > 0;
        let summary;
        if (!anyFilled && !missed.length) summary = "Nothing to fill.";
        else if (!anyFilled) summary = "No matching fields found on this page. Open the Create Article form and try again.";
        else summary = "Filled: " + filled.join(", ") + (missed.length ? " | Not found: " + missed.join(", ") : "");
        if (warnings.length) summary += " | Warning: " + warnings.join("; ");
        return { status: "done", anyFilled: anyFilled, filled: filled, missed: missed, summary: summary };
      }
    };
  }

  function toast(message, bg) {
    const old = document.getElementById("abm-bridge-toast");
    if (old) old.remove();
    if (!document.body) return;
    const t = document.createElement("div");
    t.id = "abm-bridge-toast";
    t.textContent = message;
    t.style.cssText =
      "position:fixed;top:20px;right:20px;z-index:2147483647;max-width:420px;" +
      "background:" + bg + ";color:#fff;padding:10px 16px;border-radius:8px;" +
      "font:600 13px/1.4 system-ui,-apple-system,Segoe UI,sans-serif;" +
      "box-shadow:0 4px 14px rgba(0,0,0,.25);pointer-events:none;transition:opacity .25s";
    document.body.appendChild(t);
    setTimeout(function () {
      t.style.opacity = "0";
      setTimeout(function () { t.remove(); }, 300);
    }, Math.min(14000, 4500 + String(message).length * 40));
  }
})();
